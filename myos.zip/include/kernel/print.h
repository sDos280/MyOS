#ifndef PRINT_H
#define PRINT_H

#include "kernel/tty.h"
#include "types.h"
#include "arg.h"

tty_t * print_get_tty();
void print_set_tty(tty_t * tty);
void print_clean_screen();

void printf(const char* format, ...);
int vsprintf(char *buf, const char *fmt, va_list args);
void print_hexdump(const void *data, size_t size); // print hexdump of something


#endif // PRINT_H