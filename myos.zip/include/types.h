#ifndef TYPES_H
#define TYPES_H

#define true	1
#define false	0

typedef char                     int8_t;
typedef unsigned char           uint8_t;
typedef short                   int16_t;
typedef unsigned short         uint16_t;
typedef int                     int32_t;
typedef unsigned int           uint32_t;
typedef long long int           int64_t;
typedef unsigned long long int uint64_t;
typedef uint32_t size_t;

#define NULL ((void *)0)

#endif // TYPES_H